document.addEventListener("DOMContentLoaded", function() {
    const feedbackForm = document.createElement("div");
    feedbackForm.id = "feedback-form";
    feedbackForm.className = "feedback-form";
    feedbackForm.innerHTML = `
        <h3>Обратная связь</h3>
        <form id="contact-form">
            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br>
            <label for="subject">Тема сообщения:</label><br>
            <input type="text" id="subject" name="subject" required><br>
            <label for="message">Сообщение:</label><br>
            <textarea id="message" name="message" required></textarea><br>
            <input type="submit" value="Отправить">
        </form>
        <button id="close-form">Закрыть</button>
    `;

    document.body.appendChild(feedbackForm);

    const openFormButton = document.getElementById("open-form");
    const closeFormButton = document.getElementById("close-form");

    openFormButton.addEventListener("click", function() {
        feedbackForm.classList.add("show");
    });

    closeFormButton.addEventListener("click", function() {
        feedbackForm.classList.remove("show");
    });

    const contactForm = document.getElementById("contact-form");
    contactForm.addEventListener("submit", function(event) {
        event.preventDefault();
    });
});
