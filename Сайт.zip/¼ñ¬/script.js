// Объявляем массив для хранения товаров в корзине
let cart = [];

// Функция для добавления товара в корзину
function addToCart() {
  let product = {
    name: 'Product Name',
    description: 'Description of the product',
    image: 'product.jpg',
    price: 50
  };
  cart.push(product);
  showNotification('Product added to cart!');
  updateCartView();
}

// Функция для отображения уведомления
function showNotification(message) {
  let notification = document.getElementById('notification');
  notification.innerText = message;
  notification.classList.add('show');
  setTimeout(function() {
    notification.classList.remove('show');
  }, 3000);
}

// Функция для отображения корзины
function renderCart() {
  let cartItems = document.querySelector('.cart-items');
  if (cartItems) {
    cartItems.innerHTML = '';
    cart.forEach(function(product, index) {
      let li = document.createElement('li');
      li.innerHTML = `
        <img src="${product.image}" alt="${product.name}">
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <p>Price: $${product.price}</p>
        <button class="remove-item" data-index="${index}">Remove</button>
      `;
      cartItems.appendChild(li);
    });
  }
}

// Функция для обновления корзины
function updateCartView() {
  renderCart();
  let total = calculateTotal();
  let totalAmount = document.getElementById('total-amount');
  if (totalAmount) {
    totalAmount.innerText = '$' + total;
  }
}

// Функция для расчета общей стоимости товаров в корзине
function calculateTotal() {
  return cart.reduce((total, product) => total + product.price, 0);
}

// Обработчик события клика на кнопку "Add to Cart"
document.getElementById('add-to-cart')?.addEventListener('click', addToCart);

// Обработчик события клика на кнопку "Remove" в корзине
document.querySelector('.cart-items')?.addEventListener('click', function(e) {
  if (e.target.classList.contains('remove-item')) {
    let index = e.target.getAttribute('data-index');
    cart.splice(index, 1);
    updateCartView();
  }
});

// Обработчик события клика на кнопку "Checkout"
document.getElementById('checkout')?.addEventListener('click', function() {
  // Перенаправляем на страницу оплаты
  window.location.href = 'payment.html';
});

// Обработчик события отправки формы оплаты
document.getElementById('payment-form')?.addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Payment successful!');
});
